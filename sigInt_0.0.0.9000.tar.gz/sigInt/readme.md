#  sigInt: A package to estimate the parameters of a discrete crisis-bargaining game
## Casey Crisman-Cox and Michael Gibilisco
## 15 May 2018

### Installation

This package can be installed using `devtools`.  Additional documentation and examples can be found in the package.
